package org.orgna.carpet_org.mixin.rule.carpet;

import carpet.commands.PlayerCommand;
import carpet.patches.EntityPlayerMPFake;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.util.SendMessageUtils;
import org.orgna.carpet_org.util.fakeplayer.FakePlayerProtectManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerCommand.class)
class PlayerCommandMixin {
    //假玩家保护
    @Inject(method = "kill", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;kill()V"), cancellable = true)
    private static void killPlayer(CommandContext<ServerCommandSource> context, CallbackInfoReturnable<Integer> cir) {
        if (CarpetOrgAdditionSettings.fakePlayerProtect) {
            String playerName = StringArgumentType.getString(context, "player");
            MinecraftServer server = context.getSource().getServer();
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(playerName);
            if (player instanceof EntityPlayerMPFake fakePlayer && FakePlayerProtectManager.isNotKill(fakePlayer)) {
                SendMessageUtils.sendWarningMessage(context.getSource(), "假玩家保护阻止你进行此操作");
                cir.setReturnValue(1);
            }
        }
    }
}
