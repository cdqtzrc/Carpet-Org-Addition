package org.orgna.carpet_org.mixin.rule;

import net.minecraft.enchantment.SwiftSneakEnchantment;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

//可再生迅捷潜行
@Mixin(SwiftSneakEnchantment.class)
public class SwiftSneakEnchantmentMixin {
    @Inject(method = "isAvailableForEnchantedBookOffer", at = @At("HEAD"), cancellable = true)
    private void canOffer(CallbackInfoReturnable<Boolean> cir) {
        if (CarpetOrgAdditionSettings.renewableSwiftSneak) {
            cir.setReturnValue(true);
        }
    }
}
