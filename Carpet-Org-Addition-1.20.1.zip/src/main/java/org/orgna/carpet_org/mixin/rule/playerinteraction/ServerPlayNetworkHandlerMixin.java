package org.orgna.carpet_org.mixin.rule.playerinteraction;

import net.minecraft.server.network.ServerPlayNetworkHandler;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.util.ruleutils.PlayerMaxInteractionDistance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ServerPlayNetworkHandler.class)
public class ServerPlayNetworkHandlerMixin {
    //修改方块最大可交互距离
    @Redirect(method = "onPlayerInteractBlock", at = @At(value = "FIELD", target = "Lnet/minecraft/server/network/ServerPlayNetworkHandler;MAX_BREAK_SQUARED_DISTANCE:D"))
    private double onPlayerInteractBlock() {
        return PlayerMaxInteractionDistance.getMaxBreakSquaredDistance();
    }

    //修改方块交互距离第二次检测
    @ModifyConstant(method = "onPlayerInteractBlock", constant = @Constant(doubleValue = 64.0))
    private double onPlayerInteractBlock(double constant) {
        return Math.max(PlayerMaxInteractionDistance.getMaxBreakSquaredDistance(), constant);
    }

    //修改实体最大交互距离
    @Redirect(method = "onPlayerInteractEntity", at = @At(value = "FIELD", target = "Lnet/minecraft/server/network/ServerPlayNetworkHandler;MAX_BREAK_SQUARED_DISTANCE:D"))
    private double onPlayerInteractEntity() {
        if (CarpetOrgAdditionSettings.maxBlockInteractionDistanceReferToEntity) {
            return PlayerMaxInteractionDistance.getMaxBreakSquaredDistance();
        }
        return PlayerMaxInteractionDistance.getDefaultInteractionDistance();
    }
}
