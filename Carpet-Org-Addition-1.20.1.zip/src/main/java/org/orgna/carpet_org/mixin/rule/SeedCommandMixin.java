package org.orgna.carpet_org.mixin.rule;

import net.minecraft.server.command.SeedCommand;
import net.minecraft.server.command.ServerCommandSource;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

//开放/seed权限
@Mixin(SeedCommand.class)
public class SeedCommandMixin {
    @Inject(method = "method_13618", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/command/ServerCommandSource;hasPermissionLevel(I)Z"), cancellable = true)
    private static void privilege(boolean bl, ServerCommandSource source, CallbackInfoReturnable<Boolean> cir) {
        if (CarpetOrgAdditionSettings.openSeedPermissions) {
            cir.setReturnValue(true);
        }
    }
}
