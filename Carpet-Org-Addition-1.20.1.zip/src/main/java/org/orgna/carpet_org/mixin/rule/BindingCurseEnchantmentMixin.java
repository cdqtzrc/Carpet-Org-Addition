package org.orgna.carpet_org.mixin.rule;

import net.minecraft.enchantment.EnchantmentHelper;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

//绑定诅咒无效化
@Mixin(EnchantmentHelper.class)
public class BindingCurseEnchantmentMixin {
    @Inject(method = "hasBindingCurse", at = @At("TAIL"), cancellable = true)
    private static void isCursed(CallbackInfoReturnable<Boolean> cir) {
        if (CarpetOrgAdditionSettings.bindingCurseInvalidation) {
            cir.setReturnValue(false);
        }
    }
}
