package org.orgna.carpet_org.mixin.rule.playerinteraction;

import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.util.ruleutils.PlayerMaxInteractionDistance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

//最大方块交互距离适用于实体
@Mixin(net.minecraft.client.render.GameRenderer.class)
public class GameRendererMixin {
    @ModifyConstant(method = "updateTargetedEntity", constant = @Constant(doubleValue = 3.0))
    private double targetedDistance(double constant) {
        if (CarpetOrgAdditionSettings.maxBlockInteractionDistanceReferToEntity) {
            //服务器最大交互距离
            return PlayerMaxInteractionDistance.getPlayerMaxInteractionDistance();
        }
        return constant;
    }

    @ModifyConstant(method = "updateTargetedEntity", constant = @Constant(doubleValue = 9.0))
    private double targetedSquaredDistance(double constant) {
        if (CarpetOrgAdditionSettings.maxBlockInteractionDistanceReferToEntity) {
            //服务器最大交互平方距离
            return PlayerMaxInteractionDistance.getMaxBreakSquaredDistance();
        }
        return constant;
    }
}
