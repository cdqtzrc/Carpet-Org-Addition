package org.orgna.carpet_org.commands;

import carpet.utils.CommandHelper;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.util.SendMessageUtils;

//自杀命令
public class KillMeCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("killMe").requires(source ->
                CommandHelper.canUseCommand(source, CarpetOrgAdditionSettings.commandKillMe)).executes(context -> {
            killMe(context);
            return 1;
        }));
    }

    //玩家自杀
    private static void killMe(CommandContext<ServerCommandSource> context) {
        ServerPlayerEntity player = context.getSource().getPlayer();
        if (player != null) {
            SendMessageUtils.broadcastStringMessage(player, "自杀了");
            player.kill();
        }
    }
}
