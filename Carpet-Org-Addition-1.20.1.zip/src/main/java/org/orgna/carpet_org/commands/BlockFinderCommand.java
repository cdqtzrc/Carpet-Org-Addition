package org.orgna.carpet_org.commands;

import carpet.utils.CommandHelper;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.block.Block;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.argument.BlockStateArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.util.BlockFinder;

public class BlockFinderCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher, CommandRegistryAccess commandBuildContext) {
        dispatcher.register(CommandManager.literal("blockFinder").requires(source ->
                        CommandHelper.canUseCommand(source, CarpetOrgAdditionSettings.commandBlockFinder)).then(CommandManager.argument("block", BlockStateArgumentType.blockState(commandBuildContext)).then(CommandManager.argument("radius", IntegerArgumentType.integer(0, 128)).executes(context -> {
                    finder(context, BlockStateArgumentType.getBlockState(context, "block").getBlockState().getBlock(), IntegerArgumentType.getInteger(context, "radius"));
                    return 1;
                })))
        );
    }

    //注解：抑制编译器警告
    @SuppressWarnings("all")
    //方块查找
    private static void finder(CommandContext<ServerCommandSource> context, Block block, int radius) {
        //获取执行命令的玩家并非空判断
        ServerPlayerEntity player = context.getSource().getPlayer();
        if (player == null) {
            return;
        }
        //获取命令执行时的方块坐标
        final BlockPos sourceBlockPos = player.getBlockPos();
        //创建一个新线程，用来查找方块
        BlockFinder blockFinder = new BlockFinder(player, player.getWorld(), sourceBlockPos, block, radius);
        //是否在单独的线程中查找
        boolean thread = false;
        if (thread) {
            //在单独的线程中查找
            blockFinder.setName("Block Finder");
            blockFinder.setPriority(10);
            blockFinder.start();
        } else {
            //在多线程中执行方块查找逻辑会非常缓慢，所以仍然在主线程中进行
            blockFinder.run();
        }
    }
}
