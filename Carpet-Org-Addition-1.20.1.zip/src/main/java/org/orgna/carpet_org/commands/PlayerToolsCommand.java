package org.orgna.carpet_org.commands;

import carpet.patches.EntityPlayerMPFake;
import carpet.utils.CommandHelper;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.command.argument.ItemStackArgumentType;
import net.minecraft.command.argument.Vec3ArgumentType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.PositionFlag;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.*;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionTypes;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.util.SendMessageUtils;
import org.orgna.carpet_org.util.TextUtils;
import org.orgna.carpet_org.util.fakeplayer.FakePlayerActionInterface;
import org.orgna.carpet_org.util.fakeplayer.FakePlayerActionType;
import org.orgna.carpet_org.util.fakeplayer.FakePlayerEnderChestScreenHandler;
import org.orgna.carpet_org.util.fakeplayer.FakePlayerProtectManager;

import java.util.Collection;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;

public class PlayerToolsCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher, CommandRegistryAccess commandBuildContext) {
        dispatcher.register(CommandManager.literal("playerTools").requires(source ->
                        CommandHelper.canUseCommand(source, CarpetOrgAdditionSettings.commandPlayerTools))
                .then(CommandManager.argument("player", EntityArgumentType.player())
                        .then(CommandManager.literal("enderChest").executes(context -> {
                            openEnderChest(context.getSource(), EntityArgumentType.getPlayer(context, "player"));
                            return 1;
                        })).then(CommandManager.literal("teleport").executes(context -> {
                            fakePlayerTp(context.getSource(), EntityArgumentType.getPlayer(context, "player"));
                            return 1;
                        })).then(CommandManager.literal("isFakePlayer").executes(context -> {
                            isFakePlayer(context.getSource(), EntityArgumentType.getPlayers(context, "player"));
                            return 1;
                        })).then(CommandManager.literal("position").executes(context -> {
                            getFakePlayerPos(context.getSource(), EntityArgumentType.getPlayer(context, "player"));
                            return 1;
                        }))/*.then(CommandManager.literal("info").then(CommandManager.literal("health").executes(context -> {
                            healthInfo(context.getSource(), EntityArgumentType.getPlayer(context, "player"));
                            return 1;
                        })).then(CommandManager.literal("hunger").executes(context -> {
                            hungerInfo(context.getSource(), EntityArgumentType.getPlayer(context, "player"));
                            return 1;
                        })).then(CommandManager.literal("armor").executes(context -> {
                            armorInfo(context.getSource(), EntityArgumentType.getPlayer(context, "player"));
                            return 1;
                        }))
                )*/.then(CommandManager.literal("heal").executes(context -> {
                            fakePlayerHeal(context.getSource(), EntityArgumentType.getPlayer(context, "player"));
                            return 1;
                        })).then(CommandManager.literal("action").then(CommandManager.literal("sorting").then(CommandManager.argument("item", ItemStackArgumentType.itemStack(commandBuildContext)).then(CommandManager.argument("this", Vec3ArgumentType.vec3()).then(CommandManager.argument("other", Vec3ArgumentType.vec3()).executes(context -> {
                                    setAction(context, EntityArgumentType.getPlayer(context, "player"), FakePlayerActionType.SORTING);
                                    return 1;
                                }))))).then(CommandManager.literal("clean").executes(context -> {
                                    setAction(context, EntityArgumentType.getPlayer(context, "player"), FakePlayerActionType.CLEAN);
                                    return 1;
                                })).then(CommandManager.literal("fill").then(CommandManager.argument("item", ItemStackArgumentType.itemStack(commandBuildContext)).executes(context -> {
                                    setAction(context, EntityArgumentType.getPlayer(context, "player"), FakePlayerActionType.FILL);
                                    return 1;
                                }))).then(CommandManager.literal("stop").executes(context -> {
                                    setAction(context, EntityArgumentType.getPlayer(context, "player"), FakePlayerActionType.STOP);
                                    return 1;
                                })).then(CommandManager.literal("craft").then(CommandManager.literal("one").then(CommandManager.argument("item", ItemStackArgumentType.itemStack(commandBuildContext)).executes(context -> {
                                    setAction(context, EntityArgumentType.getPlayer(context, "player"), FakePlayerActionType.CRAFT_ONE);
                                    return 1;
                                }))).then(CommandManager.literal("nine").then(CommandManager.argument("item", ItemStackArgumentType.itemStack(commandBuildContext)).executes(context -> {
                                    setAction(context, EntityArgumentType.getPlayer(context, "player"), FakePlayerActionType.CRAFT_NINE);
                                    return 1;
                                }))).then(CommandManager.literal("four").then(CommandManager.argument("item", ItemStackArgumentType.itemStack(commandBuildContext)).executes(context -> {
                                    setAction(context, EntityArgumentType.getPlayer(context, "player"), FakePlayerActionType.CRAFT_FOUR);
                                    return 1;
                                })))).then(CommandManager.literal("query").executes(context -> {
                                    getAction(context, EntityArgumentType.getPlayer(context, "player"));
                                    return 1;
                                })).then(CommandManager.literal("rename").then(CommandManager.argument("item", ItemStackArgumentType.itemStack(commandBuildContext)).then(CommandManager.argument("name", StringArgumentType.string()).executes(context -> {
                                    setAction(context, EntityArgumentType.getPlayer(context, "player"), FakePlayerActionType.RENAME);
                                    return 1;
                                })))).then(CommandManager.literal("stonecutting").then(CommandManager.argument("item", ItemStackArgumentType.itemStack(commandBuildContext)).then(CommandManager.argument("button", IntegerArgumentType.integer(1)).executes(context -> {
                                    setAction(context, EntityArgumentType.getPlayer(context, "player"), FakePlayerActionType.STONE_CUTTING);
                                    return 1;
                                }))))
                        )
                ));
    }

    //假玩家治疗
    private static void fakePlayerHeal(ServerCommandSource source, PlayerEntity fakePlayer) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            return;
        }
        if (isFakePlayer(player, fakePlayer)) {
            fakePlayer.heal(fakePlayer.getMaxHealth());
            fakePlayer.getHungerManager().setFoodLevel(20);
            player.sendMessage(Text.of("已回复" + fakePlayer.getName().getString() + "生命值"));
        }
    }

    //打开玩家末影箱
    private static void openEnderChest(ServerCommandSource source, PlayerEntity playerEntity) {
        PlayerEntity player = source.getPlayer();
        if (player == null) {
            return;
        }
        //检查玩家是否是假玩家或自己
        if (playerEntity instanceof EntityPlayerMPFake || playerEntity == player) {
            //创建GUI对象
            SimpleNamedScreenHandlerFactory screen = new SimpleNamedScreenHandlerFactory((i, inventory, playerEntity1) ->
                    FakePlayerEnderChestScreenHandler.getFakePlayerEnderChestScreenHandler(i, inventory, playerEntity.getEnderChestInventory(), playerEntity)
                    , playerEntity.getName());
            //打开末影箱GUI
            player.openHandledScreen(screen);
        } else {
            player.sendMessage(Text.literal("只允许操作自己和假玩家"));
        }
    }

    //假玩家传送
    private static void fakePlayerTp(ServerCommandSource source, PlayerEntity fakePlayer) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            return;
        }
        //获取假玩家名和命令执行玩家名
        String fakePlayerName = fakePlayer.getName().getString();
        String playerName = player.getName().getString();
        //判断被执行的玩家是否为假玩家
        if (!(fakePlayer instanceof EntityPlayerMPFake playerMPFake)) {
            sendNotFakePlayer(player, fakePlayer);
            return;
        }
        if (CarpetOrgAdditionSettings.fakePlayerProtect && FakePlayerProtectManager.isProtect(playerMPFake)) {
            SendMessageUtils.sendStringMessage(player, "不能传送受保护的假玩家");
            return;
        }
        ServerWorld serverWorld;
        try {
            serverWorld = Objects.requireNonNull(player.getServer()).getWorld(player.getWorld().getRegistryKey());
        } catch (NullPointerException n) {
            return;
        }
        Set<PositionFlag> set = EnumSet.noneOf(PositionFlag.class);
        //在假玩家位置播放潜影贝传送音效
        fakePlayer.getWorld().playSound(null, fakePlayer.prevX, fakePlayer.prevY, fakePlayer.prevZ, SoundEvents.ENTITY_SHULKER_TELEPORT, fakePlayer.getSoundCategory(), 1.0f, 1.0f);
        //传送
        teleport(fakePlayer, serverWorld, player.getX(), player.getY(), player.getZ(), set, player.getYaw(), player.getPitch());
        //在聊天栏显示命令反馈
        player.sendMessage(Text.literal("将" + fakePlayerName + "传送至" + playerName));
    }

    //传送 原版/tp命令中的方法，复制粘贴过来再改一下
    private static void teleport(Entity target, ServerWorld world, double x, double y, double z, Set<PositionFlag> movementFlags, float yaw, float pitch) {
        BlockPos blockPos = BlockPos.ofFloored(x, y, z);
        if (World.isValid(blockPos)) {
            float f = MathHelper.wrapDegrees(yaw);
            float g = MathHelper.wrapDegrees(pitch);
            if (target.teleport(world, x, y, z, movementFlags, f, g)) {
                label23:
                {
                    if (target instanceof LivingEntity livingEntity) {
                        if (livingEntity.isFallFlying()) {
                            break label23;
                        }
                    }
                    target.setVelocity(target.getVelocity().multiply(1.0, 0.0, 1.0));
                    target.setOnGround(true);
                }
                if (target instanceof PathAwareEntity pathAwareEntity) {
                    pathAwareEntity.getNavigation().stop();
                }
            }
        }
    }

    //判断玩家是否为假玩家
    private static void isFakePlayer(ServerCommandSource source, Collection<ServerPlayerEntity> targets) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            return;
        }
        for (ServerPlayerEntity playerEntity : targets) {
            String playerName = playerEntity.getName().getString();
            if (playerEntity instanceof EntityPlayerMPFake) {
                player.sendMessage(Text.of(playerName + "是假玩家"));
            } else {
                player.sendMessage(Text.of(playerName + "是真玩家"));
            }
        }
    }

    //获取假玩家位置
    private static void getFakePlayerPos(ServerCommandSource source, PlayerEntity fakePlayer) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            return;
        }
        if (isFakePlayer(player, fakePlayer)) {
            MutableText text = Texts.bracketed(Text.translatable("chat.coordinates", fakePlayer.getBlockX(), fakePlayer.getBlockY(), fakePlayer.getBlockZ())).styled((Style style) -> style.withColor(Formatting.GREEN).withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, fakePlayer.getBlockX() + " " + fakePlayer.getBlockY() + " " + fakePlayer.getBlockZ())).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.translatable("chat.copy.click"))));
            player.sendMessage(fakePlayer.getName().copy().append("位于" + getDimensionText(fakePlayer.getWorld()).getString()).append(text));
        }
    }

    //发送不是假玩家信息
    private static void sendNotFakePlayer(ServerPlayerEntity player, PlayerEntity fakePlayer) {
        SendMessageUtils.sendNotFakePlayer(player, fakePlayer);
    }

    //发送不是假玩家信息
    private static void sendNotFakePlayer(ServerCommandSource source, PlayerEntity fakePlayer) {
        SendMessageUtils.sendNotFakePlayer(source, fakePlayer);
    }

    //判断是否为真玩家
    private static boolean isFakePlayer(ServerPlayerEntity player, PlayerEntity fakePlayer) {
        if (fakePlayer instanceof EntityPlayerMPFake) {
            return true;
        } else {
            sendNotFakePlayer(player, fakePlayer);
            return false;
        }
    }

    //获取维度名称
    private static Text getDimensionText(World world) {
        Identifier value = world.getDimensionKey().getValue();
        if (value.equals(DimensionTypes.OVERWORLD_ID)) {
            return Text.of("主世界");
        } else if (value.equals(DimensionTypes.THE_NETHER_ID)) {
            return Text.of("下界");
        } else if (value.equals(DimensionTypes.THE_END_ID)) {
            return Text.of("末地");
        }
        return Text.of("未知的维度");
    }

    //保留两位小数
    private static String keepTwoDecimalPlaces(double number) {
        return String.format("%.2f", number);
    }

    //获取假玩家血量信息
    private static void healthInfo(ServerCommandSource source, PlayerEntity fakePlayer) {
        String health = keepTwoDecimalPlaces(fakePlayer.getHealth());
        showInfo(source, fakePlayer, "生命值", health);
    }

    //获取假玩家饱和度信息
    private static void hungerInfo(ServerCommandSource source, PlayerEntity fakePlayer) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            return;
        }
        if (isFakePlayer(player, fakePlayer)) {
            String fakePlayerName = fakePlayer.getName().getString();
            HungerManager hungerManager = fakePlayer.getHungerManager();
            player.sendMessage(Text.of(fakePlayerName + "的饥饿值为:" + keepTwoDecimalPlaces(hungerManager.getFoodLevel()) + "，饱和度为:" + keepTwoDecimalPlaces(hungerManager.getSaturationLevel()) + "，消耗度为:" + keepTwoDecimalPlaces(hungerManager.getExhaustion())));
        }
    }

    //获取假玩家护甲值信息
    private static void armorInfo(ServerCommandSource source, PlayerEntity fakePlayer) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            return;
        }
        if (isFakePlayer(player, fakePlayer)) {
            showInfo(source, fakePlayer, "护甲值", Integer.toString(fakePlayer.getArmor()));
        }
    }

    //显示信息
    private static void showInfo(ServerCommandSource source, PlayerEntity fakePlayer, String attribute, String number) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            return;
        }
        if (isFakePlayer(player, fakePlayer)) {
            player.sendMessage(Text.of(fakePlayer.getName().getString() + "的" + attribute + "为:" + number));
        }
    }

    //设置假玩家操作类型
    private static void setAction(CommandContext<ServerCommandSource> context, ServerPlayerEntity fakePlayer, FakePlayerActionType action) {
        ServerCommandSource source = context.getSource();
        //判断该玩家是否为假玩家，此处必须为假玩家，否则抛出类型转换异常
        if (fakePlayer instanceof EntityPlayerMPFake entityPlayerMPFake) {
            //将假玩家类型强转为假玩家动作接口
            FakePlayerActionInterface fakePlayerActionInterface = (FakePlayerActionInterface) entityPlayerMPFake;
            //设置假玩家的操作类型和命令的参数
            fakePlayerActionInterface.setAction(action);
            fakePlayerActionInterface.setContext(context);
        } else if (source != null) {
            sendNotFakePlayer(source, fakePlayer);
        }
    }

    //获取假玩家操作类型
    private static void getAction(CommandContext<ServerCommandSource> context, ServerPlayerEntity fakePlayer) {
        ServerPlayerEntity player = context.getSource().getPlayer();
        if (player == null) {
            return;
        }
        FakePlayerActionType action = ((FakePlayerActionInterface) fakePlayer).getAction();
        SendMessageUtils.sendTextMessage(player, TextUtils.appendAll(fakePlayer.getName().getString(), ": ", getActionText(action)));
    }

    //获取假玩家操作类型的字符串或可变文本形式
    private static Object getActionText(FakePlayerActionType action) {
        switch (action) {
            case STOP -> {
                return "停止";
            }
            case SORTING -> {
                return "分拣";
            }
            case CLEAN -> {
                return TextUtils.appendAll("清空", TextUtils.getItemName(Items.SHULKER_BOX));
            }
            case FILL -> {
                return TextUtils.appendAll("填充", TextUtils.getItemName(Items.SHULKER_BOX));
            }
            case CRAFT_ONE -> {
                return "合成(单个物品)";
            }
            case CRAFT_FOUR -> {
                return "合成(四个相同物品)";
            }
            case CRAFT_NINE -> {
                return "合成(九个相同物品)";
            }
            case RENAME -> {
                return "重命名";
            }
            case STONE_CUTTING -> {
                return "切石";
            }
            default -> {
                return "未知的操作类型";
            }
        }
    }
}
