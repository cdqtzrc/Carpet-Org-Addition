package org.orgna.carpet_org.commands;

import carpet.patches.EntityPlayerMPFake;
import carpet.utils.CommandHelper;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.exception.NotFoundPlayerException;
import org.orgna.carpet_org.util.SendMessageUtils;
import org.orgna.carpet_org.util.StringUtils;
import org.orgna.carpet_org.util.fakeplayer.FakePlayerProtectManager;
import org.orgna.carpet_org.util.fakeplayer.FakePlayerProtectType;

import java.util.List;

public class ProtectCommand {
    //用来补全受保护玩家的名字
    private static SuggestionProvider<ServerCommandSource> getServerCommandSourceSuggestionProvider() {
        return (context, builder) -> {
            List<ServerPlayerEntity> list = context.getSource().getServer().getPlayerManager().getPlayerList();
            return CommandSource.suggestMatching(
                    list.stream().filter(player -> player instanceof EntityPlayerMPFake fakePlayer
                            && FakePlayerProtectManager.isProtect(fakePlayer)).map(player -> player.getName().getString())
                    , builder);
        };
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register((CommandManager.literal("protect")
                        .requires(source -> CommandHelper.canUseCommand(source, CarpetOrgAdditionSettings.commandProtect))
                        .then(CommandManager.literal("add")
                                .then(CommandManager.argument("targets", EntityArgumentType.player())
                                        .executes(context -> {
                                                    setFakePlayerProtectType(context.getSource(), EntityArgumentType.getPlayer(context, "targets"), FakePlayerProtectType.KILL);
                                                    return 1;
                                                }
                                        ).then(CommandManager.literal("kill").executes(context -> {
                                                    setFakePlayerProtectType(context.getSource(), EntityArgumentType.getPlayer(context, "targets"), FakePlayerProtectType.KILL);
                                                    return 1;
                                                })
                                        ).then(CommandManager.literal("damage").executes(context -> {
                                                    setFakePlayerProtectType(context.getSource(), EntityArgumentType.getPlayer(context, "targets"), FakePlayerProtectType.DAMAGE);
                                                    return 1;
                                                })
                                        ).then(CommandManager.literal("death").executes(context -> {
                                                    setFakePlayerProtectType(context.getSource(), EntityArgumentType.getPlayer(context, "targets"), FakePlayerProtectType.DEATH);
                                                    return 1;
                                                })
                                        )
                                ))
                        .then(CommandManager.literal("list").executes(context -> {
                                            ListProtectPlayer(context);
                                            return 1;
                                        }
                                )
                        ).then(CommandManager.literal("remove").then(CommandManager.literal("name").then(CommandManager.argument("player", StringArgumentType.string())
                                        .suggests(getServerCommandSourceSuggestionProvider())
                                        .executes(context -> {
                                            String name = StringArgumentType.getString(context, "player");
                                            try {
                                                setFakePlayerProtectType(context.getSource(), getPlayer(context, name), FakePlayerProtectType.NONE);
                                            } catch (NotFoundPlayerException e) {
                                                SendMessageUtils.sendStringMessage(context.getSource(), "未找到名为" + name + "的玩家");
                                            }
                                            return 1;
                                        }))
                                ).then(CommandManager.literal("all").executes(context -> {
                                            fromProtectListRemoveAllPlayer(context.getSource());
                                            return 1;
                                        })
                                )
                        )
                )
        );
    }

    //列出所有受保护的玩家
    private static void ListProtectPlayer(CommandContext<ServerCommandSource> context) {
        ServerCommandSource source = context.getSource();
        List<ServerPlayerEntity> list = source.getServer().getPlayerManager().getPlayerList();
        int count = getProtectPlayerCount(source.getServer());
        SendMessageUtils.sendStringMessage(source, count == 0 ? "当前没有玩家受保护" : "当前有" + count + "个玩家受保护");
        for (ServerPlayerEntity player : list) {
            if (player instanceof EntityPlayerMPFake fakePlayer && FakePlayerProtectManager.isProtect(fakePlayer)) {
                SendMessageUtils.sendStringMessage(source, fakePlayer.getName().getString() + ": "
                        + FakePlayerProtectManager.getProtect(fakePlayer).toString());
            }
        }
    }

    //设置假玩家的保护类型
    private static void setFakePlayerProtectType(ServerCommandSource source, PlayerEntity player, FakePlayerProtectType protectType) {
        if (player instanceof EntityPlayerMPFake fakePlayer) {
            if (protectType.isProtect()) {
                String type = protectType.toString();
                addPlayerToProtectList(source, fakePlayer, protectType, type);
            } else {
                fromProtectListRemovePlayer(source, fakePlayer);
            }
        } else {
            SendMessageUtils.sendStringMessage(player, player.getName().getString() + "不是假玩家");
        }
    }

    //添加玩家到受保护玩家列表
    private static void addPlayerToProtectList(ServerCommandSource source, EntityPlayerMPFake fakePlayer, FakePlayerProtectType protectType, String type) {
        String playerName = fakePlayer.getName().getString();
        if (FakePlayerProtectManager.isProtect(fakePlayer)) {
            boolean flag = FakePlayerProtectManager.setProtect(fakePlayer, protectType);
            SendMessageUtils.sendStringMessage(source, flag ? StringUtils.addAll("将", playerName, "的保护类型修改为", type)
                    : playerName + "的保护类型已经是" + type);
        } else {
            FakePlayerProtectManager.setProtect(fakePlayer, protectType);
            SendMessageUtils.sendStringMessage(source, StringUtils.addAll("将", playerName, "加入受保护玩家列表(类型:", type, ")"));
        }
    }

    //设置假玩家不受保护
    private static void fromProtectListRemovePlayer(ServerCommandSource source, EntityPlayerMPFake fakePlayer) {
        String playerName = fakePlayer.getName().getString();
        if (FakePlayerProtectManager.isProtect(fakePlayer)) {
            FakePlayerProtectManager.setProtect(fakePlayer, FakePlayerProtectType.NONE);
            SendMessageUtils.sendStringMessage(source, "将" + playerName + "从受保护玩家列表中移除");
        } else {
            SendMessageUtils.sendStringMessage(source, "未在受保护玩家列表中找到此玩家");
        }
    }

    //设置所有玩家不受保护
    private static void fromProtectListRemoveAllPlayer(ServerCommandSource source) {
        List<ServerPlayerEntity> list = source.getServer().getPlayerManager().getPlayerList();
        int count = 0;
        for (ServerPlayerEntity player : list) {
            if (player instanceof EntityPlayerMPFake fakePlayer && FakePlayerProtectManager.isProtect(fakePlayer)) {
                FakePlayerProtectManager.setProtect(fakePlayer, FakePlayerProtectType.NONE);
                count++;
            }
        }
        SendMessageUtils.sendStringMessage(source, count == 0 ? "当前没有玩家受保护" : "在受保护玩家列表中移除了" + count + "个玩家");
    }

    //根据玩家名获取玩家
    private static ServerPlayerEntity getPlayer(CommandContext<ServerCommandSource> context, String name) {
        ServerPlayerEntity player = context.getSource().getServer().getPlayerManager().getPlayer(name);
        if (player == null) {
            throw new NotFoundPlayerException();
        }
        return player;
    }

    //获取受保护玩家数量
    private static int getProtectPlayerCount(MinecraftServer server) {
        List<ServerPlayerEntity> list = server.getPlayerManager().getPlayerList();
        int count = 0;
        for (ServerPlayerEntity player : list) {
            if (player instanceof EntityPlayerMPFake fakePlayer && FakePlayerProtectManager.isProtect(fakePlayer)) {
                count++;
            }
        }
        return count;
    }
}