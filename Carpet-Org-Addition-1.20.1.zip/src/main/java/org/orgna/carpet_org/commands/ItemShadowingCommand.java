package org.orgna.carpet_org.commands;

import carpet.utils.CommandHelper;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;

public class ItemShadowingCommand {

    public ItemShadowingCommand() {
    }

    //注册用于制作物品分身的/itemshadowing命令
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register((CommandManager.literal("itemshadowing").requires(source -> CommandHelper.canUseCommand(source, CarpetOrgAdditionSettings.commandItemShadowing)).executes(context -> {
            PlayerEntity player = context.getSource().getPlayer();
            if (player != null) {
                itemShadowing(player);
            }
            return 1;
        })));
    }

    //制作物品分身
    private static void itemShadowing(PlayerEntity player) {
        //非空判断
        if (player != null) {
            ItemStack main = player.getMainHandStack();
            ItemStack off = player.getOffHandStack();
            if (main != null) {
                if (main.isEmpty()) {
                    player.sendMessage(Text.literal("主手为空"));
                } else if (off.isEmpty()) {
                    player.setStackInHand(Hand.OFF_HAND, player.getMainHandStack());
                } else {
                    player.sendMessage(Text.literal("副手不为空"));
                }
            }
        }
    }
}
