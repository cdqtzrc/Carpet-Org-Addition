package org.orgna.carpet_org.commands;

import carpet.utils.CommandHelper;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.world.GameMode;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.util.SendMessageUtils;

//在生存模式和旁观模式间切换
public class SpectatorCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("spectator").requires(source -> CommandHelper.canUseCommand(source, CarpetOrgAdditionSettings.commandSpectator)).executes(context -> {
            setGameMode(context);
            return 1;
        }));
    }

    //更改游戏模式
    private static void setGameMode(CommandContext<ServerCommandSource> context) {
        ServerCommandSource source = context.getSource();
        if (source == null) {
            return;
        }
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            SendMessageUtils.sendStringMessage(source, "期望一个玩家来执行此命令");
            return;
        }
        if (player.isSpectator()) {
            GameMode survival = GameMode.SURVIVAL;
            player.changeGameMode(survival);
            MutableText text = Text.translatable("gameMode." + survival.getName());
            player.sendMessage(Text.translatable("commands.gamemode.success.self", text), true);
        } else {
            GameMode spectator = GameMode.SPECTATOR;
            player.changeGameMode(spectator);
            MutableText text = Text.translatable("gameMode." + spectator.getName());
            player.sendMessage(Text.translatable("commands.gamemode.success.self", text), true);
        }
    }
}
