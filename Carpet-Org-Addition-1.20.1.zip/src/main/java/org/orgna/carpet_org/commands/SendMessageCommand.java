package org.orgna.carpet_org.commands;

import carpet.utils.CommandHelper;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.*;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionTypes;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.util.CommonText;

public class SendMessageCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("sendMessage").requires(source -> CommandHelper.canUseCommand(source, CarpetOrgAdditionSettings.commandSendMessage)).then(CommandManager.literal("copy").then(CommandManager.argument("text", StringArgumentType.string()).executes(context -> {
                    sendReplicableText(context);
                    return 1;
                }))).then(CommandManager.literal("url").then(CommandManager.argument("url", StringArgumentType.string()).executes(context -> {
                    sendClickableLink(context);
                    return 1;
                }))).then(CommandManager.literal("location").executes(context -> {
                    sendYourOwnLocation(context);
                    return 1;
                }))
        );
    }

    //发送可复制文本
    private static void sendReplicableText(CommandContext<ServerCommandSource> context) {
        //获取命令来源，并进行非空判断
        ServerCommandSource source = context.getSource();
        if (source == null) {
            return;
        }
        //获取玩家对象
        ServerPlayerEntity serverPlayerEntity = source.getPlayer();
        //创建可变文本对象，进行异常处理和赋值
        MutableText text;
        //在输入命令时输入的消息
        text = Text.literal(StringArgumentType.getString(context, "text"));
        //将输入的消息转换为字符串
        String strText = text.getString();
        //获取玩家管理器
        PlayerManager playerManager = source.getServer().getPlayerManager();
        //给文本添加颜色，单击事件，鼠标悬停事件，然后通过玩家管理器发送出去
        MutableText styledText = text.styled(style ->
                style.withColor(Formatting.GREEN).withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, strText)).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, CommonText.CLICK_TO_COPY_TO_CLIPBOARD_TEXT))
        );
        //如果是玩家发送的，在前面追加玩家名
        if (serverPlayerEntity != null) {
            Text name = serverPlayerEntity.getName();
            styledText = name.copy().append(": ").append(styledText);
        }
        playerManager.broadcast(styledText, false);
    }

    //发送可点击链接
    private static void sendClickableLink(CommandContext<ServerCommandSource> context) {
        //获取命令来源，并非空判断
        ServerCommandSource source = context.getSource();
        if (source == null) {
            return;
        }
        ServerPlayerEntity serverPlayerEntity = source.getPlayer();
        //创建可变文本对象
        MutableText text;
        text = Text.literal(StringArgumentType.getString(context, "url"));
        String strUrl = text.getString();
        MutableText styledText = text.styled(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, strUrl)).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, CommonText.CLICK_EVENT_OPEN_URL_TEXT)).withUnderline(true));
        //获取玩家管理器对象
        PlayerManager playerManager = source.getServer().getPlayerManager();
        if (serverPlayerEntity != null) {
            MutableText playerNameText = serverPlayerEntity.getName().copy();
            styledText = playerNameText.append(": ").append(styledText);
        }
        playerManager.broadcast(styledText, false);
    }

    /**
     * 编程第一法则：
     * 如果你的代码以某种莫名其妙的方式运行起来了，就不要再碰它了
     */

    //发送自己的位置
    private static void sendYourOwnLocation(CommandContext<ServerCommandSource> context) {
        //获取命令来源，并非空判断
        ServerCommandSource source = context.getSource();
        if (source == null) {
            return;
        }
        //获取执行命令玩家，并非空判断
        ServerPlayerEntity serverPlayerEntity = source.getPlayer();
        PlayerManager playerManager = source.getServer().getPlayerManager();
        if (serverPlayerEntity == null) {
            return;
        }
        double xPos = serverPlayerEntity.getX();
        double yPos = serverPlayerEntity.getY();
        double zPos = serverPlayerEntity.getZ();
        MutableText pos = Texts.bracketed(Text.translatable("chat.coordinates", Math.round(xPos), Math.round(yPos), Math.round(zPos)));
        pos.styled(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, Math.round(xPos) + " " + Math.round(yPos) + " " + Math.round(zPos))).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, CommonText.CLICK_TO_COPY_TO_CLIPBOARD_TEXT)));
        Text nameText = serverPlayerEntity.getName();
        playerManager.broadcast(nameText.copy().append("在").append(getDimensionText(serverPlayerEntity.getWorld())).append(": ").append(getDimensionColour(serverPlayerEntity.getWorld(), pos, xPos, yPos, zPos)), false);
    }

    //获取所在维度的坐标
    private static Text getDimensionColour(World world, MutableText pos, double xPos, double yPos, double zPos) {
        Identifier value = world.getDimensionKey().getValue();
        if (value.equals(DimensionTypes.OVERWORLD_ID)) {
            setColor(pos, Formatting.GREEN).append(appendArrow()).append(appendAnotherDimensionText(world, xPos, yPos, zPos));
        } else if (value.equals(DimensionTypes.THE_NETHER_ID)) {
            setColor(pos, Formatting.RED).append(appendArrow()).append(appendAnotherDimensionText(world, xPos, yPos, zPos));
        } else if (value.equals(DimensionTypes.THE_END_ID)) {
            setColor(pos, Formatting.DARK_PURPLE);
        }
        return pos;
    }

    //设置坐标的颜色
    private static MutableText setColor(MutableText text, Formatting color) {
        return text.styled(style -> style.withColor(color));
    }

    //追加对应维度坐标
    private static Text appendAnotherDimensionText(World world, double xPos, double yPos, double zPos) {
        Identifier value = world.getDimensionKey().getValue();
        if (value.equals(DimensionTypes.OVERWORLD_ID)) {
            return (Texts.bracketed(Text.translatable("chat.coordinates", Math.round(xPos / 8), Math.round(yPos), Math.round(zPos / 8)))).styled(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, Math.round(xPos / 8) + " " + Math.round(yPos) + " " + Math.round(zPos / 8))).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, CommonText.CLICK_TO_COPY_TO_CLIPBOARD_TEXT)).withColor(Formatting.RED));
        } else if (value.equals(DimensionTypes.THE_NETHER_ID)) {
            return (Texts.bracketed(Text.translatable("chat.coordinates", Math.round(xPos * 8), Math.round(yPos), Math.round(zPos * 8)))).styled(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, Math.round(xPos * 8) + " " + Math.round(yPos) + " " + Math.round(zPos * 8))).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, CommonText.CLICK_TO_COPY_TO_CLIPBOARD_TEXT)).withColor(Formatting.GREEN));
        }
        return Text.of("未知的维度");
    }

    //在文本后追加箭头
    private static Text appendArrow() {
        return Text.literal(" --> ");
    }

    //获取维度名称
    private static Text getDimensionText(World world) {
        Identifier value = world.getDimensionKey().getValue();
        if (value.equals(DimensionTypes.OVERWORLD_ID)) {
            return Text.of("主世界");
        } else if (value.equals(DimensionTypes.THE_NETHER_ID)) {
            return Text.of("下界");
        } else if (value.equals(DimensionTypes.THE_END_ID)) {
            return Text.of("末地");
        }
        return Text.of("未知的维度");
    }
}
