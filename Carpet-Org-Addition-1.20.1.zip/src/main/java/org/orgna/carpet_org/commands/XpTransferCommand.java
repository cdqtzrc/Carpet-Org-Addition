package org.orgna.carpet_org.commands;

import carpet.patches.EntityPlayerMPFake;
import carpet.utils.CommandHelper;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.util.MathUtils;
import org.orgna.carpet_org.util.SendMessageUtils;
import org.orgna.carpet_org.util.StringUtils;

public class XpTransferCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("xpTransfer").requires(source -> CommandHelper.canUseCommand(source, CarpetOrgAdditionSettings.commandXpTransfer)).then(CommandManager.argument("outputPlayer", EntityArgumentType.player()).then(CommandManager.argument("inputPlayer", EntityArgumentType.player())
                        .then(CommandManager.literal("all").executes(context -> {
                            xpAllTransfer(context);
                            return 1;
                        })).then(CommandManager.literal("half").executes(context -> {
                            xpHalfTransfer(context);
                            return 1;
                        })).then(CommandManager.literal("points").then(CommandManager.argument("number", IntegerArgumentType.integer(0))
                                .executes(context -> {
                                    xpPointTransfer(context, null);
                                    return 1;
                                }))).then(CommandManager.literal("level").then(CommandManager.argument("level", IntegerArgumentType.integer(0))
                                        .executes(context -> {
                                            xpPointTransfer(context, MathUtils.getTotalExperience(IntegerArgumentType.getInteger(context, "level"), 0));
                                            return 1;
                                        })
                                )
                        )
                ))
        );
    }

    //转移所有经验
    private static void xpAllTransfer(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
        //获取命令执行者
        ServerPlayerEntity serverCommandSourcePlayer = context.getSource().getPlayer();
        //获取输出经验的玩家
        PlayerEntity outputPlayer = getOutputPlayer(context);
        //获取输入经验的玩家
        PlayerEntity inputPlayer = getInputPlayer(context);
        if (inputPlayer == null) {
            return;
        }
        //输出经验的玩家必须是假玩家或者是命令执行者自己
        if (outputPlayer instanceof EntityPlayerMPFake || outputPlayer == serverCommandSourcePlayer) {
            //获取玩家当前的经验值
            int points = MathHelper.floor(outputPlayer.experienceProgress * (float) outputPlayer.getNextLevelExperience());
            //获取玩家的总经验值
            int totalExperience = MathUtils.getTotalExperience(outputPlayer.experienceLevel, points);
            //清除输出玩家的经验
            ((ServerPlayerEntity) outputPlayer).setExperienceLevel(0);
            ((ServerPlayerEntity) outputPlayer).setExperiencePoints(0);
            //把经验给输入玩家
            inputPlayer.addExperience(totalExperience);
            if (serverCommandSourcePlayer != null) {
                SendMessageUtils.sendStringMessage(serverCommandSourcePlayer, "将" + outputPlayer.getName().getString() + "所有的经验共" + totalExperience + "转移给" + inputPlayer.getName().getString());
            }
        } else {
            if (serverCommandSourcePlayer != null) {
                //发送需要目标是自己或假玩家消息
                SendMessageUtils.sendSelfOrFakePlayer(serverCommandSourcePlayer);
            }
        }
    }

    //转移一半经验
    private static void xpHalfTransfer(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
        //获取命令执行者玩家
        ServerPlayerEntity serverCommandSourcePlayer = context.getSource().getPlayer();
        //获取输出经验的玩家
        PlayerEntity outputPlayer = getOutputPlayer(context);
        //获取输入经验的玩家
        PlayerEntity inputPlayer = getInputPlayer(context);
        if (inputPlayer == null) {
            return;
        }
        //只能操作自己或假玩家
        if (outputPlayer instanceof EntityPlayerMPFake || outputPlayer == serverCommandSourcePlayer) {
            //获取玩家当前的经验值
            int points = MathHelper.floor(outputPlayer.experienceProgress * (float) outputPlayer.getNextLevelExperience());
            //获取玩家的总经验值
            int totalExperience = MathUtils.getTotalExperience(outputPlayer.experienceLevel, points);
            //将玩家的经验值取半
            int halfExperience = totalExperience / 2;
            //清除输出玩家的所有经验
            ((ServerPlayerEntity) outputPlayer).setExperienceLevel(0);
            ((ServerPlayerEntity) outputPlayer).setExperiencePoints(0);
            //将输出玩家一半的经验转移至输出玩家身上
            inputPlayer.addExperience(halfExperience);
            //将另一半经验再转移到输出玩家身上
            outputPlayer.addExperience(totalExperience - halfExperience);
            if (serverCommandSourcePlayer != null) {
                SendMessageUtils.sendStringMessage(serverCommandSourcePlayer, "将" + outputPlayer.getName().getString() + "一半的经验共" + halfExperience + "转移给" + inputPlayer.getName().getString());
            }
        } else {
            if (serverCommandSourcePlayer != null) {
                //发送消息：只允许操作自己或假玩家
                SendMessageUtils.sendSelfOrFakePlayer(serverCommandSourcePlayer);
            }
        }
    }

    //转移指定数量经验
    private static void xpPointTransfer(CommandContext<ServerCommandSource> context, @Nullable Integer number) throws CommandSyntaxException {
        //获取命令执行者玩家
        ServerPlayerEntity serverCommandSourcePlayer = context.getSource().getPlayer();
        //获取输出经验的玩家
        PlayerEntity outputPlayer = getOutputPlayer(context);
        //获取输入经验的玩家
        PlayerEntity inputPlayer = getInputPlayer(context);
        //获取要转移的经验数量
        int xpNumber = number == null ? IntegerArgumentType.getInteger(context, "number") : number;
        if (inputPlayer == null) {
            return;
        }
        //只能操作自己或假玩家
        if (outputPlayer instanceof EntityPlayerMPFake || outputPlayer == serverCommandSourcePlayer) {
            //获取玩家当前的经验值
            int points = MathHelper.floor(outputPlayer.experienceProgress * (float) outputPlayer.getNextLevelExperience());
            //获取玩家的总经验值
            int totalExperience = MathUtils.getTotalExperience(outputPlayer.experienceLevel, points);
            if (xpNumber > totalExperience) {
                if (serverCommandSourcePlayer != null) {
                    SendMessageUtils.sendStringMessage(serverCommandSourcePlayer, StringUtils.getPlayerName(outputPlayer) + "没有这么多经验(" + xpNumber + ">" + totalExperience + ")");
                    return;
                }
            }
            //清除输出玩家的所有经验
            ((ServerPlayerEntity) outputPlayer).setExperienceLevel(0);
            ((ServerPlayerEntity) outputPlayer).setExperiencePoints(0);
            //将指定数量的经验添加改输入玩家
            inputPlayer.addExperience(xpNumber);
            //将剩余的经验再添加回输出玩家
            outputPlayer.addExperience(totalExperience - xpNumber);
            if (serverCommandSourcePlayer != null) {
                SendMessageUtils.sendStringMessage(serverCommandSourcePlayer, "将" + StringUtils.getPlayerName(outputPlayer) + "的" + xpNumber + "点经验转移给" + StringUtils.getPlayerName(inputPlayer));
            }
        } else {
            if (serverCommandSourcePlayer != null) {
                //发送消息：只允许操作自己或假玩家
                SendMessageUtils.sendSelfOrFakePlayer(serverCommandSourcePlayer);
            }
        }
    }

    //获取要输出经验的玩家
    private static PlayerEntity getOutputPlayer(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
        return EntityArgumentType.getPlayer(context, "outputPlayer");
    }

    //获取要输入经验的玩家
    private static PlayerEntity getInputPlayer(CommandContext<ServerCommandSource> context) throws CommandSyntaxException {
        return EntityArgumentType.getPlayer(context, "inputPlayer");
    }
}
