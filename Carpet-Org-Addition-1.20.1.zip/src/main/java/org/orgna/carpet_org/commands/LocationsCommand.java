package org.orgna.carpet_org.commands;

import carpet.utils.CommandHelper;
import com.google.gson.JsonParseException;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.BlockPosArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;
import org.orgna.carpet_org.util.SendMessageUtils;
import org.orgna.carpet_org.util.StringUtils;
import org.orgna.carpet_org.util.location.Location;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

//路径点管理器
public class LocationsCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("locations")
                .requires(source -> CommandHelper.canUseCommand(source, CarpetOrgAdditionSettings.commandLocations))
                .then(CommandManager.literal("add")
                        .then(CommandManager.argument("name", StringArgumentType.string())
                                .executes(context -> {
                                    addWayPoint(context, null);
                                    return 1;
                                })
                                .then(CommandManager.argument("pos", BlockPosArgumentType.blockPos())
                                        .executes(context -> {
                                            addWayPoint(context, BlockPosArgumentType.getBlockPos(context, "pos"));
                                            return 1;
                                        })
                                )
                        )
                ).then(CommandManager.literal("list")
                        .executes(context -> {
                            listWayPoint(context, null);
                            return 1;
                        }).then(CommandManager.argument("filter", StringArgumentType.string())
                                .executes(context -> {
                                    listWayPoint(context, StringArgumentType.getString(context, "filter"));
                                    return 1;
                                })
                        )
                ).then(CommandManager.literal("supplement")
                        .then(CommandManager.argument("supp", StringArgumentType.string())
                                .suggests(getServerCommandSourceSuggestionProvider())
                                .then(CommandManager.literal("illustrate")
                                        .then(CommandManager.argument("illustrate", StringArgumentType.string())
                                                .executes(context -> {
                                                    addIllustrateText(context);
                                                    return 1;
                                                })
                                        )
                                ).then(CommandManager.literal("another_pos")
                                        .executes(context -> {
                                            addAnotherPos(context, null);
                                            return 1;
                                        })
                                        .then(CommandManager.argument("anotherPos", BlockPosArgumentType.blockPos())
                                                .executes(context -> {
                                                    addAnotherPos(context, BlockPosArgumentType.getBlockPos(context, "anotherPos"));
                                                    return 1;
                                                })
                                        ))
                        )
                ).then(CommandManager.literal("info")
                        .then(CommandManager.argument("info", StringArgumentType.string())
                                .suggests(getServerCommandSourceSuggestionProvider())
                                .executes(context -> {
                                    showInfo(context);
                                    return 1;
                                })
                        )
                )
                .then(CommandManager.literal("delete")
                        .then(CommandManager.argument("delete", StringArgumentType.string())
                                .suggests(getServerCommandSourceSuggestionProvider())
                                .executes(context -> {
                                    deleteWayPoint(context);
                                    return 1;
                                })
                        )
                )
        );
    }

    @NotNull
    //用来自动补全命令
    private static SuggestionProvider<ServerCommandSource> getServerCommandSourceSuggestionProvider() {
        return (context, builder) -> {
            File file = getFile(context.getSource().getWorld());
            File[] files = file.listFiles();
            if (files != null) {
                return CommandSource.suggestMatching(Arrays.stream(files).map(File::getName)
                        .filter(name -> name.endsWith(".json")).map(LocationsCommand::removeExtension)
                        .map(StringArgumentType::escapeIfRequired), builder);
            }
            return null;
        };
    }

    //添加路径点
    private static void addWayPoint(CommandContext<ServerCommandSource> context, @Nullable BlockPos blockPos) {
        ServerPlayerEntity player = context.getSource().getPlayer();
        if (player == null) {
            return;
        }
        //获取路径点名称和位置对象
        String name = StringArgumentType.getString(context, "name");
        if (blockPos == null) {
            blockPos = player.getBlockPos();
        }
        //创建路径点对象
        Location location = new Location(blockPos, StringUtils.getDimensionId(player.getWorld()), player);
        //获取文件对象
        File file = getFile(player.getWorld());
        File[] files = file.listFiles();
        String tempName = name + ".json";
        //遍历文件夹，检查该路径点是否已存在，如果存在，添加失败
        if (files != null) {
            for (File f : files) {
                if (tempName.equals(f.getName())) {
                    SendMessageUtils.sendStringMessage(player, "无法添加路径点：[" + name + "]已存在");
                    return;
                }
            }
        }
        try {
            //添加路径点并写入本地文件
            Location.saveLoc(file, location, name);
            SendMessageUtils.sendStringMessage(player, "路径点[" + name + "]已添加(" + StringUtils.getBlockPosString(blockPos) + ")");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //列出所有路径点
    private static void listWayPoint(CommandContext<ServerCommandSource> context, @Nullable String filter) {
        ServerPlayerEntity player = context.getSource().getPlayer();
        if (player == null) {
            return;
        }
        //获取并遍历文件夹
        File file = getFile(player.getWorld());
        File[] files = file.listFiles();
        if (files != null) {
            SendMessageUtils.sendStringMessage(player, "------------------------------");
            for (File f : files) {
                try {
                    String name = f.getName();
                    //只显示包含指定字符串的路径点，如果为null，显示所有路径点
                    if (filter != null && !name.contains(filter)) {
                        continue;
                    }
                    //从本地文件读取路径点对象
                    Location location;
                    try {
                        location = Location.loadLoc(file, name);
                    } catch (JsonParseException e) {
                        SendMessageUtils.sendStringMessage(player, "无法解析坐标[" + removeExtension(name) + "]");
                        continue;
                    }
                    //删除文件扩展名，然后在聊天栏输出路径点的文本
                    name = removeExtension(name);
                    SendMessageUtils.sendTextMessage(player, location.getText("[" + name + "] "));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            SendMessageUtils.sendStringMessage(player, "------------------------------");
        }
    }

    //添加说明文本
    private static void addIllustrateText(CommandContext<ServerCommandSource> context) {
        ServerPlayerEntity player = context.getSource().getPlayer();
        if (player == null) {
            return;
        }
        String name = StringArgumentType.getString(context, "supp");
        try {
            //从本地文件读取路径点对象
            Location location = Location.loadLoc(getFile(player.getWorld()), name + ".json");
            String illustrate = StringArgumentType.getString(context, "illustrate");
            //为路径点对象设置说明文本
            location.setIllustrate(illustrate);
            //将路径点对象写入本地文件
            Location.saveLoc(getFile(player.getWorld()), location, name);
            SendMessageUtils.sendStringMessage(player, "将说明文本“" + illustrate + "”添加到[" + name + "]中");
        } catch (JsonParseException e) {
            SendMessageUtils.sendStringMessage(player, "无法解析坐标");
        } catch (IOException e) {
            SendMessageUtils.sendStringMessage(player, "无法为路径点[" + name + "]添加说明文本");
        }
    }

    //添加另一个坐标
    private static void addAnotherPos(CommandContext<ServerCommandSource> context, @Nullable BlockPos blockPos) {
        ServerPlayerEntity player = context.getSource().getPlayer();
        if (player == null) {
            return;
        }
        String name = StringArgumentType.getString(context, "supp");
        try {
            //从本地文件读取路径点对象
            Location location = Location.loadLoc(getFile(player.getWorld()), name + ".json");
            try {
                //为路径点对象添加对象坐标
                if (blockPos == null) {
                    blockPos = player.getBlockPos();
                }
                location.addAnotherPos(blockPos);
                //将路径点对象写入本地文件
                Location.saveLoc(getFile(player.getWorld()), location, name);
                SendMessageUtils.sendStringMessage(player, "对向坐标已添加");
            } catch (UnsupportedOperationException e) {
                SendMessageUtils.sendStringMessage(player, "不能为末地坐标添加对向坐标");
            }
        } catch (JsonParseException e) {
            SendMessageUtils.sendStringMessage(player, "无法解析坐标");
        } catch (IOException e) {
            SendMessageUtils.sendStringMessage(player, "无法为路径点[" + name + "]添加对向坐标");
        }
    }

    //显示详细信息
    private static void showInfo(CommandContext<ServerCommandSource> context) {
        ServerPlayerEntity player = context.getSource().getPlayer();
        if (player == null) {
            return;
        }
        String name = StringArgumentType.getString(context, "info");
        try {
            //从本地文件读取路径点对象
            Location location = Location.loadLoc(getFile(player.getWorld()), name + ".json");
            //显示路径点对象的详细信息
            location.showInfo(player, name);
        } catch (JsonParseException e) {
            SendMessageUtils.sendStringMessage(player, "无法解析坐标");
        } catch (IOException e) {
            SendMessageUtils.sendStringMessage(player, "无法显示路径点[" + name + "]的详细信息");
        }
    }

    //删除路径点
    private static void deleteWayPoint(CommandContext<ServerCommandSource> context) {
        ServerPlayerEntity player = context.getSource().getPlayer();
        if (player == null) {
            return;
        }
        //获取路径点文件名
        String delete = StringArgumentType.getString(context, "delete");
        //获取路径点文件对象
        File file = new File(getFile(player.getWorld()), delete + ".json");
        //从本地文件删除路径点
        boolean flag = file.delete();
        SendMessageUtils.sendStringMessage(player, flag ? "路径点[" + delete + "]已删除" : "无法删除路径点[" + delete + "]");
    }

    //获取文件
    private static File getFile(World world) {
        return Objects.requireNonNull(world.getServer())
                .getSavePath(WorldSavePath.ROOT).resolve("locations").toFile();
    }

    //删除扩展名
    private static String removeExtension(String fileName) {
        if (fileName.endsWith(".json")) {
            return fileName.substring(0, fileName.lastIndexOf("."));
        }
        return fileName;
    }
}
