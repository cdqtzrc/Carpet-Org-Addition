package org.orgna.carpet_org.client;

import net.fabricmc.api.ClientModInitializer;

public class CarpetOrgClient implements ClientModInitializer {
    /**
     * Runs the mod initializer on the client environment.
     */
    @Override
    public void onInitializeClient() {
    }
}
