package org.orgna.carpet_org.exception;

/**
 * 空潜影盒异常<br/>
 * 尝试获取无NBT潜影盒的NBT时抛出
 */
public class EmptyShulkerBoxException extends NullPointerException {
    public EmptyShulkerBoxException() {
    }
}
