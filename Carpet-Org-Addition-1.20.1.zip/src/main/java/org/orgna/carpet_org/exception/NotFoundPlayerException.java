package org.orgna.carpet_org.exception;

/**
 * 找不到玩家异常
 */
public class NotFoundPlayerException extends RuntimeException {
    public NotFoundPlayerException() {
    }
}
