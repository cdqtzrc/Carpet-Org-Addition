package org.orgna.carpet_org.util.fakeplayer;

public interface FakePlayerProtectInterface {
    //获取假玩家保护类型
    FakePlayerProtectType getProtect();

    //设置假玩家保护类型
    void setProtected(FakePlayerProtectType protect);
}
