package org.orgna.carpet_org.util.fakeplayer;

import carpet.patches.EntityPlayerMPFake;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import org.jetbrains.annotations.Nullable;
import org.orgna.carpet_org.util.SendMessageUtils;

public class FakePlayerUtils {
    /**
     * 工具类，私有化构造方法
     */
    private FakePlayerUtils() {
    }

    /**
     * 丢弃物品<br/>
     * 将要丢弃的物品堆栈对象复制一份并丢出，然后将原本的物品堆栈对象删除，这种方式丢弃物品不会更新比较器，但是比模拟Ctrl+Q丢弃物品更节省性能，如果确实需要更新比较器，比如丢弃潜影盒中的物品，应该使用{@link #throwItem(ScreenHandler, int, PlayerEntity)}方法，或者使用本方法丢弃物品，再调用其他方法更新比较器，如果要丢出功能方块输出槽位的物品，不应该使用本方法，因为这不会同时清除合成槽位的物品
     *
     * @param player    当前要丢弃物品的玩家
     * @param itemStack 要丢弃的物品堆栈对象
     */
    public static void dropItem(PlayerEntity player, ItemStack itemStack) {
        player.dropItem(itemStack.copy(), false, false);
        itemStack.setCount(0);
    }

    /**
     * 模拟Ctrl+Q丢弃物品<br/>
     * 如果当前槽位索引为0，表示按Ctrl+Q丢弃0索引槽位的物品<br/>
     * 使用这种方式丢弃物品可以更新比较器，但是需要使用更多性能，如果丢弃物品时不需要更新比较器，比如丢弃玩家物品栏中的物品，应该使用{@link #dropItem(PlayerEntity, ItemStack)}方法以节约性能，但是如果需要丢出一些功能方块输出槽位的物品，应该使用本方法，因为这会同时清除合成槽位的物品
     *
     * @param screenHandler 假玩家当前打开的GUI
     * @param slotIndex     假玩家当前操作槽位的索引
     * @param player        当前操作的假玩家
     */
    public static void throwItem(ScreenHandler screenHandler, int slotIndex, PlayerEntity player) {
        screenHandler.onSlotClick(slotIndex, 1, SlotActionType.THROW, player);
    }

    /**
     * 与快捷栏中的物品交互位置<br/>
     * 如果当前操作的槽位索引为0，数字键为1，表示0索引槽位的物品与玩家1号快捷栏的物品交换位置
     *
     * @param screenHandler 假玩家当前打开的GUI
     * @param slotIndex     假玩家当前操作槽位的索引
     * @param key           模拟按下的数字键
     * @param player        当前操作的假玩家
     */
    public static void swapItem(ScreenHandler screenHandler, int slotIndex, int key, PlayerEntity player) {
        screenHandler.onSlotClick(slotIndex, key, SlotActionType.SWAP, player);
    }

    /**
     * 假玩家停止物品合成操作，并广播停止合成的消息
     *
     * @param playerMPFake 需要停止操作的假玩家
     */
    public static void stopCraftAction(EntityPlayerMPFake playerMPFake) {
        ((FakePlayerActionInterface) playerMPFake).setAction(FakePlayerActionType.STOP);
        try {
            SendMessageUtils.broadcastWithColonMessage(playerMPFake, "无法合成物品，停止合成");
            //空指针异常
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 让假玩家停止重命名操作，并广播停止重命名的消息
     *
     * @param playerMPFake 需要停止操作的假玩家
     */
    public static void stopRenameAction(EntityPlayerMPFake playerMPFake) {
        ((FakePlayerActionInterface) playerMPFake).setAction(FakePlayerActionType.STOP);
        try {
            SendMessageUtils.broadcastWithColonMessage(playerMPFake, "无法重命名，操作自动停止");
            //空指针异常
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 让假玩家停止当前的操作
     *
     * @param playerMPFake 要停止操作的假玩家
     * @param illustrate   停止操作时在聊天栏输出的内容
     */
    public static void stopAction(EntityPlayerMPFake playerMPFake, String illustrate) {
        ((FakePlayerActionInterface) playerMPFake).setAction(FakePlayerActionType.STOP);
        try {
            SendMessageUtils.broadcastWithColonMessage(playerMPFake, illustrate);
            //空指针异常
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 模拟按住Shift快速移动物品
     *
     * @param screenHandler 当前打开的GUI
     * @param slotIndex     要操作的槽位的索引
     * @param player        当前操作的玩家
     */
    public static void quickMove(ScreenHandler screenHandler, int slotIndex, PlayerEntity player) {
        screenHandler.quickMove(player, slotIndex);
    }

    /**
     * 模拟光标拾取并丢出物品，作用与{@link #throwItem(ScreenHandler, int, PlayerEntity)}模拟Ctrl+Q丢出物品类似，但是可能有些GUI的槽位不能使用Ctrl+Q丢弃物品，这时可以尝试使用本方法
     *
     * @param screenHandler 玩家当前打开的GUI
     * @param slotIndex     玩家当前操作的索引
     * @param player        当前操作GUI的假玩家
     */
    public static void pickupAndThrow(ScreenHandler screenHandler, int slotIndex, PlayerEntity player) {
        screenHandler.onSlotClick(slotIndex, 0, SlotActionType.PICKUP, player);
        FakePlayerUtils.dropItem(player, screenHandler.getCursorStack());
    }

    /**
     * 使用循环一个个丢弃槽位中的物品<br/>
     * 如果有些功能方块的输出槽位既不能使用Ctrl+Q丢弃，也不能使用鼠标拿起再丢弃，如切石机的输出槽，那么可以尝试使用本方法，使用时，应先确定确实不能使用上述两种方法进行丢弃，相比前面两种只需要一次操作的方法，本方法需要多次丢弃物品，这会更加消耗性能，增加游戏卡顿，因此，当前两种方法可用时，应使用前两种
     *
     * @param screenHandler 玩家当前打开的GUI
     * @param count         要循环的次数，如果为null，表示循环当前槽位的物品堆叠数次
     * @param slotIndex     玩家当前操作槽位的索引
     * @param player        当前操作该GUI的玩家
     */
    public static void loopThrowItem(ScreenHandler screenHandler, @Nullable Integer count, int slotIndex, PlayerEntity player) {
        int loopCount = (count == null ? screenHandler.getSlot(slotIndex).getStack().getCount() : count);
        for (int i = 0; i < loopCount; i++) {
            screenHandler.onSlotClick(slotIndex, 0, SlotActionType.THROW, player);
        }
    }
}