package org.orgna.carpet_org.util.ruleutils;

import net.minecraft.util.math.MathHelper;
import org.orgna.carpet_org.CarpetOrgAdditionSettings;

import static net.minecraft.server.network.ServerPlayNetworkHandler.MAX_BREAK_SQUARED_DISTANCE;

public class PlayerMaxInteractionDistance {
    private PlayerMaxInteractionDistance() {
    }

    /**
     * 获取Carpet Org设置的玩家最大交互距离并进行判断，小于0的值会被视为6.0，超过128的值会被视为128.0
     *
     * @return 当前设置的最大交互距离，最大不超过128
     */
    public static double getPlayerMaxInteractionDistance() {
        double distance = CarpetOrgAdditionSettings.maxBlockInteractionDistance;
        if (distance < 0) {
            return 6.0;
        }
        return Math.min(distance, 128.0);
    }

    /**
     * 获取玩家最大交互距离的平方
     *
     * @return 当前设置的最大交互距离，然后取平方
     */
    public static double getMaxBreakSquaredDistance() {
        return MathHelper.square(getPlayerMaxInteractionDistance());
    }

    /**
     * 获取游戏默认的交互距离的平方
     *
     * @return 默认的交互距离，取平方距离
     */

    public static double getDefaultInteractionDistance() {
        return MAX_BREAK_SQUARED_DISTANCE;
    }
}
