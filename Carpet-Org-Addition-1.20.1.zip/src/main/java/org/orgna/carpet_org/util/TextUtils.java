package org.orgna.carpet_org.util;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.text.*;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

public class TextUtils {
    private TextUtils() {
    }

    /**
     * 获取一个方块坐标的可变文本对象，并带有点击复制、悬停文本，颜色效果
     *
     * @param color 文本的颜色，如果为null，不修改颜色
     */
    public static MutableText blockPos(BlockPos blockPos, @Nullable Formatting color) {
        MutableText pos = Texts.bracketed(Text.translatable("chat.coordinates", blockPos.getX(), blockPos.getY(), blockPos.getZ()));
        //添加单击事件，复制方块坐标
        pos.styled(style ->
                style.withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, StringUtils.getBlockPosString(blockPos)))
        );
        //添加光标悬停事件：单击复制到剪贴板
        pos.styled(style -> style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, CommonText.CLICK_TO_COPY_TO_CLIPBOARD_TEXT)));
        if (color != null) {
            //修改文本颜色
            pos.styled(style -> style.withColor(color));
        }
        return pos;
    }

    /**
     * 获取一个带有悬浮文本的可变文本对象
     *
     * @param text  要显示的文本
     * @param hover 显示在文本上的悬浮文字
     */
    public static MutableText hoverText(String text, String hover) {
        return Text.literal(text).styled(style
                -> style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal(hover))));
    }

    /**
     * 获取一个方块名称的可变文本形式
     *
     * @param block 要获取名称的方块
     */
    public static MutableText getBlockName(Block block) {
        return Text.translatable(block.getTranslationKey());
    }

    /**
     * 获取一个物品名称的可变文本形式
     *
     * @param item 要获取名称的物品
     */
    public static MutableText getItemName(Item item) {
        return Text.translatable(item.getTranslationKey());
    }

    /**
     * 将一堆零散的字符串和可变文本拼接成一个大的可变文本
     *
     * @param objects 要拼接的文本，可以是字符串，也可以是文本，但不能是其他类型，否则抛出非法参数异常
     * @return 拼接后的可变文本对象
     */
    public static MutableText appendAll(Object... objects) {
        MutableText mutableText = Text.literal("");
        for (Object object : objects) {
            if (object instanceof String str) {
                mutableText.append(Text.literal(str));
            } else if (object instanceof Text text) {
                mutableText.append(text);
            } else {
                throw new IllegalArgumentException();
            }
        }
        return mutableText;
    }
}
