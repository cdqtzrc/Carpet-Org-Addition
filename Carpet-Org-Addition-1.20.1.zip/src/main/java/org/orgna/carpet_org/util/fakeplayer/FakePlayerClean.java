package org.orgna.carpet_org.util.fakeplayer;

import carpet.patches.EntityPlayerMPFake;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.collection.DefaultedList;

public class FakePlayerClean {
    private FakePlayerClean() {
    }

    public static void clean(EntityPlayerMPFake fakePlayer) {
        //判断假玩家打开的界面是不是潜影盒的GUI
        if (fakePlayer.currentScreenHandler instanceof ShulkerBoxScreenHandler shulkerBoxScreenHandler) {
            //是否更新比较器
            boolean flag = false;
            //获取GUI的每一个槽位
            DefaultedList<Slot> slots = fakePlayer.currentScreenHandler.slots;
            for (Slot slot : slots) {
                //根据槽位依次获取里面的每一个物品堆栈对象
                ItemStack stack = slot.getStack();
                if (stack.isEmpty()) {
                    continue;
                }
                //如果潜影盒物品栏没有任何物品，那么语句不会执行到这里
                flag = true;
                //丢弃物品堆栈
                FakePlayerUtils.dropItem(fakePlayer, stack);
            }
            //模拟单击一次物品栏，用来更新比较器
            //清空完容器再单击即可，没必要被操作一次物品就单击一次
            //如果潜影盒物品栏为空，也不需要单击
            if (flag) {
                shulkerBoxScreenHandler.onSlotClick(0, 0, SlotActionType.PICKUP, fakePlayer);
            }
        }
    }
}
