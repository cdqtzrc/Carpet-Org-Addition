package org.orgna.carpet_org.util;

import net.minecraft.block.Block;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.World;
import org.orgna.carpet_org.exception.OperationTimeoutException;

import java.util.TreeSet;

/**
 * 方块查找器
 */
public class BlockFinder extends Thread {
    ServerPlayerEntity player;
    World world;
    BlockPos blockPos;
    Block block;
    int radius;

    public BlockFinder(ServerPlayerEntity player, World world, BlockPos blockPos, Block block, int radius) {
        this.player = player;
        this.world = world;
        this.blockPos = blockPos;
        this.block = block;
        this.radius = radius;
    }

    @Override
    public void run() {
        try {
            TreeSet<BlockPos> treeSet = findBlock(this.world, this.blockPos, this.block, this.radius);
            sendFeedback(this.block, this.player, treeSet, this.blockPos);
        } catch (OperationTimeoutException e) {
            SendMessageUtils.sendWarningMessage(player, "查找方块超时");
        }
    }

    /**
     * 获取指定范围内所有指定方块的坐标
     *
     * @param world    要查找方块的世界对象
     * @param blockPos 查找范围的中心坐标
     * @param block    要查找的方块
     * @param radius   查找的范围，是一个边长为两倍radius，高度为整个世界高度的长方体
     * @return 包含所有查找到的方块坐标和该方块距离源方块坐标的距离的集合，并且已经从近到远排序
     */
    private static TreeSet<BlockPos> findBlock(World world, BlockPos blockPos, Block block, int radius) {
        //创建TreeSet集合，用来记录找到的方块坐标
        TreeSet<BlockPos> treeSet = new TreeSet<>((o1, o2) -> MathUtils.compareBlockPos(blockPos, o1, o2));
        //获取三个坐标的最大值
        int maxX = blockPos.getX() + radius;
        int maxZ = blockPos.getZ() + radius;
        int maxHeight = world.getHeight();
        long currentTimeMillis = System.currentTimeMillis();
        //创建可变坐标对象
        Mutable mutableBlockPos = new Mutable();
        //遍历整个三维空间，找到与目标方块匹配的方块
        for (int minX = blockPos.getX() - radius; minX <= maxX; minX++) {
            for (int minZ = blockPos.getZ() - radius; minZ <= maxZ; minZ++) {
                for (int bottomY = world.getBottomY(); bottomY <= maxHeight; bottomY++) {
                    if (System.currentTimeMillis() - currentTimeMillis > 3000) {
                        //3秒内未完成方块查找，通过抛出异常结束方法
                        throw new OperationTimeoutException();
                    }
                    //修改可变坐标的值
                    mutableBlockPos.set(minX, bottomY, minZ);
                    if (world.getBlockState(mutableBlockPos).getBlock() == block) {
                        //将找到的方块坐标添加到集合
                        treeSet.add(new BlockPos(mutableBlockPos.getX(), mutableBlockPos.getY(), mutableBlockPos.getZ()));
                    }
                }
            }
        }
        return treeSet;
    }

    //发送命令反馈
    private static void sendFeedback(Block block, ServerPlayerEntity player, TreeSet<BlockPos> treeSet, BlockPos sourceBlockPos) {
        //判断集合中是否有元素
        if (treeSet.size() == 0) {
            SendMessageUtils.sendTextMessage(player, Text.literal("在指定范围内找不到").append(TextUtils.getBlockName(block)));
        } else {
            //在聊天栏输出方块坐标消息
            int count = 0;
            if (treeSet.size() > 10) {
                SendMessageUtils.sendTextMessage(player, Text.literal("在指定范围内找到" + treeSet.size() + "个").append(TextUtils.getBlockName(block)).append("，距离你最近的10个分别是："));
                for (BlockPos blockPos : treeSet) {
                    count++;
                    if (count > 10) {
                        break;
                    }
                    SendMessageUtils.sendBlockPos(player, count + ". 距离: " + (int) MathUtils.getBlockDistance(sourceBlockPos, blockPos) + "格 ", blockPos);
                }

            } else {
                SendMessageUtils.sendTextMessage(player, Text.literal("在指定范围内找到" + treeSet.size() + "个").append(TextUtils.getBlockName(block)));
                for (BlockPos blockPos : treeSet) {
                    count++;
                    SendMessageUtils.sendBlockPos(player, count + ". 距离: " + (int) MathUtils.getBlockDistance(sourceBlockPos, blockPos) + "格 ", blockPos);
                }
            }
        }
    }
}
