package org.orgna.carpet_org.util.fakeplayer;

public enum FakePlayerActionType {
    //假玩家停止操作
    STOP,
    //假玩家物品分拣
    SORTING,
    //假玩家清空容器
    CLEAN,
    //假玩家填充容器
    FILL,
    //假玩家自动合成物品（单个材料）
    CRAFT_ONE,
    //假玩家合成物品（四个相同的材料）
    CRAFT_FOUR,
    //假玩家自动合成物品（九个相同的材料）
    CRAFT_NINE,
    //假玩家自动重命名
    RENAME,
    //假玩家切石机
    STONE_CUTTING;
}
