package org.orgna.carpet_org.util;

import net.minecraft.text.Text;

public class CommonText {
    /**
     * 点击打开网页链接
     */
    public static final Text CLICK_EVENT_OPEN_URL_TEXT = Text.literal("点击打开网页链接");
    /**
     * 单击复制到剪贴板
     */
    public static final Text CLICK_TO_COPY_TO_CLIPBOARD_TEXT = Text.translatable("chat.copy.click");
}
