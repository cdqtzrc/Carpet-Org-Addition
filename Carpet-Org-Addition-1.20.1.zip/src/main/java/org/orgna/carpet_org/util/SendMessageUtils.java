package org.orgna.carpet_org.util;

import carpet.utils.Messenger;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public class SendMessageUtils {
    private SendMessageUtils() {
    }

    /**
     * 发送目标玩家不是假玩家的消息，消息内容仅对消息发送者可见
     *
     * @param playerSelf 要发送消息的玩家
     * @param playerFake 目标玩家
     */
    public static void sendNotFakePlayer(PlayerEntity playerSelf, PlayerEntity playerFake) {
        playerSelf.sendMessage(Text.literal(playerFake.getName().getString() + "不是假玩家"));
    }

    /**
     * 发送目标玩家不是假玩家的消息，消息内容仅对消息发送者可见
     *
     * @param source     要发送消息的命令源
     * @param playerFake 目标玩家
     */
    public static void sendNotFakePlayer(ServerCommandSource source, PlayerEntity playerFake) {
        source.sendMessage(Text.literal(playerFake.getName().getString() + "不是假玩家"));
    }

    /**
     * 发送需要目标是自己或假玩家消息，消息内容仅对消息发送者可见
     *
     * @param player 消息发送者
     */
    public static void sendSelfOrFakePlayer(PlayerEntity player) {
        player.sendMessage(Text.literal("只允许操作自己或假玩家"));
    }

    /**
     * 让一个玩家发送指定内容的消息，消息内容仅对消息发送者可见
     *
     * @param player  发送消息的玩家
     * @param message 发送消息的内容
     */
    public static void sendStringMessage(PlayerEntity player, String message) {
        player.sendMessage(Text.literal(message));
    }

    /**
     * 让一个玩家发送带有特殊样式的文本，文本内容仅对消息发送者可见
     *
     * @param player  要发送文本消息的玩家
     * @param message 发送文本消息的内容
     */
    public static void sendTextMessage(PlayerEntity player, Text message) {
        player.sendMessage(message);
    }

    /**
     * 让服务器命令源发送指定内容的消息，消息内容仅对消息发送者可见
     *
     * @param source  发送消息的消息源
     * @param message 要发送消息的内容
     */
    public static void sendStringMessage(ServerCommandSource source, String message) {
        source.sendMessage(Text.literal(message));
    }

    /**
     * 发送一个方块坐标的位置，该位置是一个绿色的，有悬浮文本，可以单击复制的坐标文本，并且用“[]”括起来，消息内容仅对发送者可见
     *
     * @param player   要发送消息的玩家
     * @param message  在坐标文本前添加字符串前缀，如果为null，直接发送位置文本
     * @param blockPos 要发送的方块位置
     */
    public static void sendBlockPos(PlayerEntity player, @Nullable String message, BlockPos blockPos) {
        MutableText text = TextUtils.blockPos(blockPos, Formatting.GREEN);
        player.sendMessage(message == null ? text : Text.literal(message).append(text));
    }

    /**
     * 广播指定内容的消息，消息对所有玩家可见，带有冒号
     *
     * @param player  消息的发送者
     * @param message 消息的内容
     */
    public static void broadcastWithColonMessage(PlayerEntity player, String message) {
        try {
            PlayerManager playerManager = Objects.requireNonNull(player.getServer()).getPlayerManager();
            playerManager.broadcast(Text.literal(player.getName().getString() + ": " + message), false);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 广播指定内容的消息，消息对所有玩家可见，不带冒号
     *
     * @param player  消息的发送者
     * @param message 消息的内容
     */
    public static void broadcastStringMessage(PlayerEntity player, String message) {
        try {
            PlayerManager playerManager = Objects.requireNonNull(player.getServer()).getPlayerManager();
            playerManager.broadcast(Text.literal(player.getName().getString() + message), false);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 发送一条警告消息，消息文本颜色为红色，消息内容仅发送者可见
     *
     * @param player  消息的发送者
     * @param message 发送消息的内容
     */
    public static void sendWarningMessage(PlayerEntity player, String message) {
        Messenger.m(player, "r " + message);
    }

    /**
     * 发送一条警告消息，消息内容对自己和管理员可见
     *
     * @param source  要发送消息的玩家
     * @param message 要发送消息的内容
     */
    public static void sendWarningMessage(ServerCommandSource source, String message) {
        Messenger.m(source, "r " + message);
    }
}
