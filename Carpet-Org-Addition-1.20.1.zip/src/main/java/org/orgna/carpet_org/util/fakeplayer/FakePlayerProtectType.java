package org.orgna.carpet_org.util.fakeplayer;

public enum FakePlayerProtectType {
    NONE,//不受保护
    KILL,//不被kill
    DAMAGE,//不被伤害
    DEATH;//不会死亡

    @Override
    public String toString() {
        return switch (this) {
            case NONE -> "不受保护";
            case KILL -> "不被kill";
            case DAMAGE -> "不被伤害";
            case DEATH -> "不会死亡";
        };
    }

    //是否为受保护的类型
    public boolean isProtect() {
        return this != NONE;
    }
}
